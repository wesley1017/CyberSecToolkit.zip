# Port Scanner
# Author: Wesley Attram

import socket

def scan_port(target, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.connect((target, port))
        print(f"Port {port} is open on {target}")
        s.close()
    except:
        pass

if __name__ == "__main__":
    target = input("Enter target IP: ")
    for port in range(20, 1025):
        scan_port(target, port)
