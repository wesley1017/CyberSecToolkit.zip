# Hash Generator
# Author: Wesley Attram

import hashlib

def generate_hash(text, algo="sha256"):
    h = hashlib.new(algo)
    h.update(text.encode())
    return h.hexdigest()

if __name__ == "__main__":
    text = input("Enter text to hash: ")
    print("SHA-256:", generate_hash(text))
