# Password Strength Checker
# Author: Wesley Attram

import re

def check_password_strength(password):
    if len(password) < 8:
        return "Weak: Too short"
    if not re.search("[a-z]", password) or not re.search("[A-Z]", password):
        return "Weak: Must contain both uppercase and lowercase letters"
    if not re.search("[0-9]", password):
        return "Weak: Must contain a number"
    if not re.search("[!@#$%^&*(),.?":{}|<>]", password):
        return "Weak: Must contain a special character"
    return "Strong"

if __name__ == "__main__":
    password = input("Enter password: ")
    print(check_password_strength(password))
